import Foundation


func couldAttend(intervals: [[Int]]) -> Bool {
    guard intervals.count > 1 else { return true }
    
    let sortedIn = intervals.sorted { l, r in
        return l[0] < r[0]
    }
    
    for index in 1..<sortedIn.count {
        let i1 = sortedIn[index - 1]
        let i2 = sortedIn[index]
        
        if i1[1] > i2[0] {
            return false
        }
    }
    
    return true
}

let given = [[7, 10], [2, 4]]
print(couldAttend(intervals: given))
