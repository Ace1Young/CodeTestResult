import Foundation


func isOverlapping(intervals: [[Int]]) -> Bool {
    let sortedIn = intervals.sorted { l, r in
        return l[0] < r[0]
    }
    
    for index in 1..<sortedIn.count {
        let i1 = sortedIn[index - 1]
        let i2 = sortedIn[index]
        
        if i1[1] > i2[0] {
            return false
        }
    }
    return true
}


print(isOverlapping(intervals: [[1, 5], [8, 9], [8, 10]]))
