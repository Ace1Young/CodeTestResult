import Foundation


func isOverlapping(intervals: [[Int]]) -> Bool {
    let tem = intervals.sorted { l, r in
        return l[0] < r[0]
    }
//    print(tem)
    for index in 1..<tem.count {
        let i1 = tem[index - 1]
        let i2 = tem[index]
        
        if i1[1] > i2[0] {
            return false
        }
    }
    return true
}


print(isOverlapping(intervals: [[1, 5], [8, 9], [8, 10]]))
